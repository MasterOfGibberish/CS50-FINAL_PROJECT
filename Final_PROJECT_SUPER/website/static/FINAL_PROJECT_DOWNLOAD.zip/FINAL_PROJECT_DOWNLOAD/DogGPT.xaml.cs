﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FINAL_PROJECT_DOWNLOAD
{
    /// <summary>
    /// Interaction logic for DogGPT.xaml
    /// </summary>
    public partial class DogGPT : Window
    {
        public DogGPT()
        {
            InitializeComponent();
        }

        private void migtukas_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void GenerateAufButton_Click(object sender, RoutedEventArgs e)
        {
            string userInput = UserInputTextBox.Text;
            int aufCount = new Random().Next(10);
            string aufString = new string('a', aufCount) + "uf";

            TextBlock chatLine = new TextBlock();
            chatLine.Margin = new Thickness(5);
            chatLine.FontSize = 20;
            chatLine.Foreground = Brushes.Goldenrod;
            chatLine.Text = $"You: {userInput}\nBot: {aufString}\n";
            ChatStackPanel.Children.Add(chatLine);

            ChatScrollViewer.ScrollToEnd();

            UserInputTextBox.Clear();
        }
    }
}
