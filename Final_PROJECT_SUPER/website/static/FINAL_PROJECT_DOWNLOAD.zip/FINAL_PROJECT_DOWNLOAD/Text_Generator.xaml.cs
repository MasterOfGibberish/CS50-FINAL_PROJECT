﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FINAL_PROJECT_DOWNLOAD
{
    /// <summary>
    /// Interaction logic for Text_Generator.xaml
    /// </summary>
    public partial class Text_Generator : Window
    {
        private string _key = "YTNSHKVEFXRBAUQZCLWDMIPGJO";
        public Text_Generator()
        {
            InitializeComponent();
        }

        private void migtukas_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void kopijavimas_Click(object sender, RoutedEventArgs e)
        {
            Clipboard.SetText(Rezultatas.Text);
            MessageBoxResult result = MessageBox.Show("Copied successfully!", "Congratulations!");
            if (result == MessageBoxResult.OK)
            {
                Konvertavimas.Clear();
                Rezultatas.Clear();
            }
        }
       
        private void Generate_Text_Click(object sender, RoutedEventArgs e)
        {
            string text = Konvertavimas.Text.ToUpper();

            if (!string.IsNullOrEmpty(text))
            {
                if (text.All(c => Char.IsLetter(c)))
                {
                    if (text.Length <= 1000)
                    {
                        string result = Substitution(text, _key);
                        Rezultatas.Text = result;
                    }
                    else
                    {
                        MessageBoxResult result = MessageBox.Show("Input text is too long. Maximum 1000 characters allowed.", "Error");
                        if (result == MessageBoxResult.OK)
                        {
                            Konvertavimas.Clear();
                            Rezultatas.Clear();
                        }

                    }
                }
                else
                {
                    MessageBoxResult result = MessageBox.Show("Input text must only contain letters.", "Error");
                    if (result == MessageBoxResult.OK)
                    {
                        Konvertavimas.Clear();
                        Rezultatas.Clear();
                    }
                }
            }
            else
            {
                MessageBoxResult result =  MessageBox.Show("Please enter input text.", "Error");
                if (result == MessageBoxResult.OK)
                {
                    Konvertavimas.Clear();
                    Rezultatas.Clear();
                }
            }
        }

        private string Substitution(string text, string key)
        {
            string alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            string result = "";

            foreach (char c in text)
            {
                if (Char.IsLetter(c))
                {
                    int index = alphabet.IndexOf(c);
                    result += Char.IsUpper(c) ? Char.ToUpper(key[index]) : Char.ToLower(key[index]);
                }
                else
                {
                    result += c;
                }
            }

            return result;
        }

        private void Decrypt_Text_Click(object sender, RoutedEventArgs e)
        {
            string text = Konvertavimas.Text.ToUpper();

            if (!string.IsNullOrEmpty(text))
            {
                if (text.All(c => Char.IsLetter(c)))
                {
                    string result = SubstitutionDecrypt(text, _key);
                    Rezultatas.Text = result;
                }
                else
                {
                    MessageBoxResult result = MessageBox.Show("Input text must only contain letters.", "Error");
                    if (result == MessageBoxResult.OK)
                    {
                        Konvertavimas.Clear();
                        Rezultatas.Clear();
                    }
                }
            }
            else
            {
                MessageBoxResult result = MessageBox.Show("Please enter input text.", "Error");
                if (result == MessageBoxResult.OK)
                {
                    Konvertavimas.Clear();
                    Rezultatas.Clear();
                }
            }

        }

        private string SubstitutionDecrypt(string text, string key)
        {
            string alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            string result = "";

            foreach (char c in text)
            {
                if (Char.IsLetter(c))
                {
                    int index = key.IndexOf(c);
                    result += Char.IsUpper(c) ? Char.ToUpper(alphabet[index]) : Char.ToLower(alphabet[index]);
                }
                else
                {
                    result += c;
                }
            }

            return result;
        }
    }
}

