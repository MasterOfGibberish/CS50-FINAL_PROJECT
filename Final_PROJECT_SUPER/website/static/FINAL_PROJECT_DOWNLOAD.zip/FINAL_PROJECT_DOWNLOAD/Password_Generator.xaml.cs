﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace FINAL_PROJECT_DOWNLOAD
{
    /// <summary>
    /// Interaction logic for Password_Generator.xaml
    /// </summary>
    public partial class Password_Generator : Window
    {

        public Password_Generator()
        {
            InitializeComponent();
        }

        private void migtukas_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    

        private void hardPassword_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void kopijavimas_Click(object sender, RoutedEventArgs e)
        {
            Clipboard.SetText(Password.Text);
            MessageBoxResult result = MessageBox.Show("Copied successfully!", "Congratulations!");
            if (result == MessageBoxResult.OK)
            {
                textBox.Clear();
                Password.Clear();
            }

        }

        private void Generate_Password_Click(object sender, RoutedEventArgs e)
        {
            char[] array = "0123456789qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM".ToCharArray(); 
            if (hardPassword.IsChecked == true)
            {
                array = "0123456789qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM!@#$%^&*()_+~?><\":}{+-".ToCharArray();
            }
            if (int.TryParse(textBox.Text, out int getnumber) && getnumber <= 50)
            {
                string randomstring = string.Empty;
                Random random = new Random();
                for (int i = 0; i < getnumber; i++)
                {
                    int point = random.Next(1, array.Length);
                    if (!randomstring.Contains(array.GetValue(point).ToString()))
                    {
                        randomstring += array.GetValue(point);
                    }
                    else
                    {
                        i--;
                    }
                }
                Password.Text = randomstring;
            }
            else
            {
                MessageBoxResult result = MessageBox.Show("Please enter a valid integer value up to 50 in the text box.", "Warning!");
                if (result == MessageBoxResult.OK)
                {
                    textBox.Clear();
                    Password.Clear();
                }
            }
        }

        private void textBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
